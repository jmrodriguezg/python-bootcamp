#Write your code below this row 👇
sum=0
for i in range(2,101,2):
  sum += i
  #print(i)
print (sum)