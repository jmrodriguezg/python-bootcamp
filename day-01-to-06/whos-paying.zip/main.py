# Split string method
names_string = input("Give me everybody's names, seperated by a comma. ")
names = names_string.split(", ")
# 🚨 Don't change the code above 👆

#Write your code below this line 👇

import random 

cant = len(names)
whoPays = random.randint(0,cant-1)

print (f"{names[whoPays]} is going to buy the meal today!")
