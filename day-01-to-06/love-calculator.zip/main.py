# 🚨 Don't change the code below 👇
print("Welcome to the Love Calculator!")
name1 = input("What is your name? \n")
name2 = input("What is their name? \n")
# 🚨 Don't change the code above 👆

#Write your code below this line 👇
comb_names = name1.lower()+name2.lower()

score1=0
keyword="true"
for letter in keyword:
  score1 += comb_names.count(letter)

score2=0
keyword="love"
for letter in keyword:
  score2 += comb_names.count(letter)

# for letter in word:
#   for n in name1:
#     if n == letter :
#       score1 += 1
#   for n in name2:
#     if n == letter :
#       score1 += 1

# score2=0
# word="love"
# for letter in word:
#   for n in name1:
#     if n == letter :
#       score2 += 1
#   for n in name2:
#     if n == letter :
#       score2 += 1

score = int(str(score1) + str(score2))

if score < 10 or score > 90 :
  print(f"Your score is {score}, you go together like coke and mentos.")
elif score >= 40 and score <= 50 :
  print(f"Your score is {score}, you are alright together.")
else:
  print(f"Your score is {score}.")