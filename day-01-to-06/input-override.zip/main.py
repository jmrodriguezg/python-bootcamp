input = 5
print ("This "+str(input)+" text")